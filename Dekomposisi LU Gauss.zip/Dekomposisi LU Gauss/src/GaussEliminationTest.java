public class GaussEliminationTest {

    public static void main(String[] args) {
        // Matriks contoh
        double[][] matrix = {
                {2, -1, 1},
                {-3, 3, 3},
                {1, 1, 5}
        };

        // Cetak matriks awal
        System.out.println("Matriks Awal:");
        GaussElimination.printMatrix(matrix);

        // Lakukan eliminasi Gauss
        GaussElimination.gaussianElimination(matrix);

        // Cetak matriks segitiga atas
        System.out.println("\nMatriks Segitiga Atas:");
        GaussElimination.printMatrix(matrix);

        // Cetak matriks segitiga bawah
        System.out.println("\nMatriks Segitiga Bawah:");
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                if (i == j) {
                    System.out.print("1\t");
                } else if (i < j) {
                    System.out.print("0\t");
                } else {
                    System.out.print(matrix[i][j] + "\t");
                }
            }
            System.out.println();
        }
    }
}