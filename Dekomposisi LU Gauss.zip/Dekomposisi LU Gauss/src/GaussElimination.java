public class GaussElimination {

    // Method untuk mencetak matriks
    public static void printMatrix(double[][] matrix) {
        int rows = matrix.length;
        int cols = matrix[0].length;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(matrix[i][j] + "\t");
            }
            System.out.println();
        }
    }

    // Method untuk melakukan eliminasi Gauss
    public static void gaussianElimination(double[][] matrix) {
        int rows = matrix.length;
        int cols = matrix[0].length;

        for (int i = 0; i < rows - 1; i++) {
            if (matrix[i][i] == 0) {
                System.out.println("Pembagian oleh nol terdeteksi. Metode gagal.");
                return;
            }
            for (int k = i + 1; k < rows; k++) {
                double factor = matrix[k][i] / matrix[i][i];
                for (int j = i; j < cols; j++) {
                    matrix[k][j] -= factor * matrix[i][j];
                }
            }
        }
    }

    public static void main(String[] args) {
        double[][] matrix = {
                {2, -1, 1},
                {-3, 3, 3},
                {1, 1, 5}
        };

        System.out.println("Matriks awal:");
        printMatrix(matrix);

        gaussianElimination(matrix);

        System.out.println("\nMatriks segitiga atas:");
        printMatrix(matrix);

        System.out.println("\nMatriks segitiga bawah:");
        // Cetak matriks dengan mengganti elemen diagonal utama dengan 1
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                if (i == j) {
                    System.out.print("1\t");
                } else if (i < j) {
                    System.out.print("0\t");
                } else {
                    System.out.print(matrix[i][j] + "\t");
                }
            }
            System.out.println();
        }
    }
}