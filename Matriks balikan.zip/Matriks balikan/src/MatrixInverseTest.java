public class MatrixInverseTest {

    public static void main(String[] args) {
        // Matriks contoh
        double[][] matrix = {{2, 3}, {1, 4}};

        // Menampilkan matriks input
        System.out.println("Matriks Input:");
        MatrixInverse.printMatrix(matrix);

        // Mencari invers matriks
        double[][] inverse = MatrixInverse.inverseMatrix(matrix);

        // Menampilkan matriks invers jika ada
        if (inverse != null) {
            System.out.println("Matriks Invers:");
            MatrixInverse.printMatrix(inverse);
        }

        // Menggunakan matriks dengan determinan nol
        double[][] singularMatrix = {{1, 2}, {2, 4}};
        System.out.println("Matriks Input (Determinan Nol):");
        MatrixInverse.printMatrix(singularMatrix);
        System.out.println("Mencari invers matriks (Determinan Nol):");
        MatrixInverse.inverseMatrix(singularMatrix);
    }
}