import java.util.Scanner;

public class MatrixInverse {

    // Fungsi untuk mencetak matriks
    public static void printMatrix(double[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }

    // Fungsi untuk mencari invers matriks 2x2
    public static double[][] inverseMatrix(double[][] matrix) {
        double det = (matrix[0][0] * matrix[1][1]) - (matrix[0][1] * matrix[1][0]);
        if (det == 0) {
            System.out.println("Determinan matriks nol, tidak ada invers.");
            return null;
        }

        double[][] inverse = new double[2][2];
        inverse[0][0] = matrix[1][1] / det;
        inverse[0][1] = -matrix[0][1] / det;
        inverse[1][0] = -matrix[1][0] / det;
        inverse[1][1] = matrix[0][0] / det;

        return inverse;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Memasukkan elemen matriks
        System.out.println("Masukkan elemen matriks 2x2:");
        double[][] matrix = new double[2][2];
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                matrix[i][j] = scanner.nextDouble();
            }
        }

        // Mencetak matriks input
        System.out.println("Matriks input:");
        printMatrix(matrix);

        // Mencari invers matriks
        double[][] inverse = inverseMatrix(matrix);

        // Mencetak matriks invers jika ada
        if (inverse != null) {
            System.out.println("Matriks Invers:");
            printMatrix(inverse);
        }

        scanner.close();
    }
}