public class CroutDecomposition {

    public static void croutDecomposition(double[][] A, double[][] L, double[][] U) {
        int n = A.length;

        for (int i = 0; i < n; i++) {
            // Mengisi elemen diagonal matriks bawah (L) dengan 1
            L[i][i] = 1;

            // Menghitung elemen matriks atas (U)
            for (int k = i; k < n; k++) {
                double sum = 0;
                for (int j = 0; j < i; j++) {
                    sum += (L[i][j] * U[j][k]);
                }
                U[i][k] = A[i][k] - sum;
            }

            // Menghitung elemen matriks bawah (L)
            for (int k = i + 1; k < n; k++) {
                double sum = 0;
                for (int j = 0; j < i; j++) {
                    sum += (L[k][j] * U[j][i]);
                }
                L[k][i] = (A[k][i] - sum) / U[i][i];
            }
        }
    }

    public static void printMatrix(double[][] matrix) {
        int rows = matrix.length;
        int cols = matrix[0].length;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.print(matrix[i][j] + "\t");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        double[][] A = {
                {2, 3, 1},
                {4, 7, 5},
                {8, 9, 10}
        };

        int n = A.length;
        double[][] L = new double[n][n];
        double[][] U = new double[n][n];

        croutDecomposition(A, L, U);

        System.out.println("Matriks L:");
        printMatrix(L);

        System.out.println("\nMatriks U:");
        printMatrix(U);
    }
}