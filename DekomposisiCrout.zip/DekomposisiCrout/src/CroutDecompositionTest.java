public class CroutDecompositionTest {

    public static void main(String[] args) {
        // Matriks contoh
        double[][] A = {
                {2, 3, 1},
                {4, 7, 5},
                {8, 9, 10}
        };

        // Mencetak matriks awal
        System.out.println("Matriks Awal:");
        CroutDecomposition.printMatrix(A);

        // Membuat matriks L dan U untuk menyimpan hasil dekomposisi
        int n = A.length;
        double[][] L = new double[n][n];
        double[][] U = new double[n][n];

        // Melakukan dekomposisi Crout
        CroutDecomposition.croutDecomposition(A, L, U);

        // Mencetak matriks segitiga bawah (L)
        System.out.println("\nMatriks Segitiga Bawah (L):");
        CroutDecomposition.printMatrix(L);

        // Mencetak matriks segitiga atas (U)
        System.out.println("\nMatriks Segitiga Atas (U):");
        CroutDecomposition.printMatrix(U);
    }
}